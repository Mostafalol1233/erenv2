import { supabase } from "./supabase"

export type Comment = {
  id: number
  name: string
  game: string
  comment: string
  created_at: string
}

export async function getComments(): Promise<Comment[]> {
  if (!supabase) {
    console.warn("⚠️ Supabase not connected")
    return []
  }

  try {
    const { data, error } = await supabase
      .from("comments")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(10)

    if (error) {
      console.error("❌ Error:", error.message)
      return []
    }

    return data || []
  } catch (e) {
    console.error("❌ Exception:", e)
    return []
  }
}

export async function addComment(name: string, game: string, comment: string): Promise<boolean> {
  if (!supabase) {
    console.warn("⚠️ Supabase not connected")
    return false
  }

  try {
    const { error } = await supabase.from("comments").insert([
      {
        name: name.trim(),
        game: game.trim(),
        comment: comment.trim(),
      },
    ])

    if (error) {
      console.error("❌ Error:", error.message)
      return false
    }

    return true
  } catch (e) {
    console.error("❌ Exception:", e)
    return false
  }
}
