import { createClient } from "@supabase/supabase-js"

const URL = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

let client: any = null

if (URL && KEY) {
  try {
    client = createClient(URL, KEY)
  } catch (e) {
    console.error("❌ Supabase Error:", e)
  }
}

export const supabase = client

export type Comment = {
  id: number
  name: string
  game: string
  comment: string
  created_at: string
}
